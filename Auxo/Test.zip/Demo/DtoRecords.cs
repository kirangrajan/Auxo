﻿namespace Demo;

public record TotalLabourCostDto(string JobId, decimal TotalCost);
public record ProblemDetailDto(string Type, string Title, string Detail);